local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local LocalPlayer = game:GetService("Players").LocalPlayer
local Camera = workspace.CurrentCamera

local flyEnabled = false
local verticalSpeed = 50
local horizontalSpeed = 50
local flyConnection = nil

UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end
    if input.KeyCode == Enum.KeyCode.F then
        flyEnabled = not flyEnabled
        if flyEnabled then
            flyConnection = RunService.Heartbeat:Connect(function()
                local char = LocalPlayer.Character
                if not char then return end
                local hrp = char:FindFirstChild("HumanoidRootPart")
                if not hrp then return end
                
                local vel = Vector3.zero
                
                if UserInputService:IsKeyDown(Enum.KeyCode.W) then
                    vel += Vector3.new(Camera.CFrame.LookVector.X, 0, Camera.CFrame.LookVector.Z).Unit * horizontalSpeed
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.S) then
                    vel -= Vector3.new(Camera.CFrame.LookVector.X, 0, Camera.CFrame.LookVector.Z).Unit * horizontalSpeed
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.A) then
                    vel -= Vector3.new(Camera.CFrame.RightVector.X, 0, Camera.CFrame.RightVector.Z).Unit * horizontalSpeed
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.D) then
                    vel += Vector3.new(Camera.CFrame.RightVector.X, 0, Camera.CFrame.RightVector.Z).Unit * horizontalSpeed
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.Space) then
                    vel += Vector3.new(0, verticalSpeed, 0)
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
                    vel -= Vector3.new(0, verticalSpeed, 0)
                end
                
                hrp.Velocity = vel
            end)
        else
            if flyConnection then
                flyConnection:Disconnect()
                flyConnection = nil
            end
            local char = LocalPlayer.Character
            if char then
                local hrp = char:FindFirstChild("HumanoidRootPart")
                if hrp then hrp.Velocity = Vector3.zero end
            end
        end
    end
end)