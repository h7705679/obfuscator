#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>

typedef enum {
    OP_NOP, OP_PUSH, OP_POP, OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD,
    OP_POW, OP_EQ, OP_LT, OP_LE, OP_NOT, OP_AND, OP_OR,
    OP_JMP, OP_JMPT, OP_JMPF, OP_CALL, OP_RET,
    OP_LOAD, OP_STORE, OP_GETG, OP_SETG, OP_NEWT,
    OP_GETT, OP_SETT, OP_CONC, OP_LEN, OP_UNM
} Opcode;

typedef struct {
    uint8_t* data;
    int pos;
    int size;
} Bytecode;

Bytecode* bc_create() {
    Bytecode* bc = (Bytecode*)malloc(sizeof(Bytecode));
    bc->data = (uint8_t*)malloc(65536);
    bc->pos = 0;
    bc->size = 65536;
    return bc;
}

void bc_write(Bytecode* bc, uint8_t byte) {
    if (bc->pos < bc->size) {
        bc->data[bc->pos++] = byte;
    }
}

void bc_write_int(Bytecode* bc, int val) {
    memcpy(bc->data + bc->pos, &val, 4);
    bc->pos += 4;
}

void bc_write_double(Bytecode* bc, double val) {
    memcpy(bc->data + bc->pos, &val, 8);
    bc->pos += 8;
}

void bc_write_string(Bytecode* bc, const char* str) {
    int len = strlen(str);
    bc_write_int(bc, len);
    memcpy(bc->data + bc->pos, str, len);
    bc->pos += len;
}

int is_digit(char c) {
    return c >= '0' && c <= '9';
}

int is_alpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
}

int is_alnum(char c) {
    return is_alpha(c) || is_digit(c);
}

int is_keyword(const char* word) {
    const char* keywords[] = {
        "local", "if", "then", "else", "elseif", "end", "for", "while",
        "do", "repeat", "until", "return", "break", "in", "nil", "true",
        "false", "and", "or", "not", "function", NULL
    };
    for (int i = 0; keywords[i]; i++) {
        if (strcmp(word, keywords[i]) == 0) return 1;
    }
    return 0;
}

int is_number(const char* str) {
    if (*str == '-' || *str == '+') str++;
    if (!*str) return 0;
    int has_dot = 0;
    while (*str) {
        if (*str == '.') {
            if (has_dot) return 0;
            has_dot = 1;
        } else if (!is_digit(*str)) {
            return 0;
        }
        str++;
    }
    return 1;
}

void xor_encrypt(const char* str, int key, uint8_t* out) {
    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        out[i] = str[i] ^ key;
    }
}

void compile_value(Bytecode* bc, const char* val, int xor_key) {
    while (*val == ' ') val++;
    
    if (*val == '"' || *val == '\'') {
        char quote = *val;
        const char* end = strrchr(val + 1, quote);
        if (end) {
            int len = end - val - 1;
            char* str = (char*)malloc(len + 1);
            memcpy(str, val + 1, len);
            str[len] = '\0';
            
            uint8_t* encrypted = (uint8_t*)malloc(len);
            xor_encrypt(str, xor_key, encrypted);
            
            bc_write(bc, OP_PUSH);
            bc_write(bc, 1);
            bc_write_string(bc, (char*)encrypted);
            bc_write_int(bc, xor_key);
            
            free(str);
            free(encrypted);
        }
    } else if (strcmp(val, "true") == 0) {
        bc_write(bc, OP_PUSH);
        bc_write(bc, 2);
        bc_write(bc, 1);
    } else if (strcmp(val, "false") == 0) {
        bc_write(bc, OP_PUSH);
        bc_write(bc, 2);
        bc_write(bc, 0);
    } else if (strcmp(val, "nil") == 0) {
        bc_write(bc, OP_PUSH);
        bc_write(bc, 3);
    } else if (is_number(val)) {
        bc_write(bc, OP_PUSH);
        bc_write(bc, 0);
        bc_write_double(bc, atof(val));
    } else {
        bc_write(bc, OP_LOAD);
        bc_write_string(bc, val);
    }
}

void compile_line(Bytecode* bc, const char* line, int xor_key) {
    while (*line == ' ') line++;
    if (!*line || strncmp(line, "--", 2) == 0) return;
    
    if (strncmp(line, "local ", 6) == 0) {
        const char* rest = line + 6;
        const char* eq = strchr(rest, '=');
        if (eq) {
            int var_len = eq - rest;
            while (rest[var_len-1] == ' ') var_len--;
            char* var = (char*)malloc(var_len + 1);
            memcpy(var, rest, var_len);
            var[var_len] = '\0';
            
            const char* val = eq + 1;
            while (*val == ' ') val++;
            compile_value(bc, val, xor_key);
            
            bc_write(bc, OP_STORE);
            bc_write_string(bc, var);
            free(var);
        }
    } else if (strncmp(line, "return ", 7) == 0) {
        compile_value(bc, line + 7, xor_key);
        bc_write(bc, OP_RET);
    } else {
        const char* paren = strchr(line, '(');
        if (paren) {
            const char* func_start = line;
            while (func_start < paren && *func_start == ' ') func_start++;
            
            int func_len = paren - func_start;
            char* func = (char*)malloc(func_len + 1);
            memcpy(func, func_start, func_len);
            func[func_len] = '\0';
            
            const char* args_start = paren + 1;
            const char* args_end = strrchr(args_start, ')');
            if (args_end) {
                char* args = (char*)malloc(args_end - args_start + 1);
                memcpy(args, args_start, args_end - args_start);
                args[args_end - args_start] = '\0';
                
                char* token = strtok(args, ",");
                int arg_count = 0;
                while (token) {
                    while (*token == ' ') token++;
                    char* end_token = token + strlen(token) - 1;
                    while (end_token > token && *end_token == ' ') end_token--;
                    *(end_token + 1) = '\0';
                    
                    compile_value(bc, token, xor_key);
                    arg_count++;
                    token = strtok(NULL, ",");
                }
                
                bc_write(bc, OP_LOAD);
                bc_write_string(bc, func);
                bc_write(bc, OP_CALL);
                bc_write_int(bc, arg_count);
                
                free(args);
            }
            free(func);
        }
    }
}

char* generate_vm_lua(Bytecode* bc, int xor_key) {
    char* output = (char*)malloc(65536);
    int pos = 0;
    
    pos += sprintf(output + pos, "local __code = \"");
    for (int i = 0; i < bc->pos; i++) {
        pos += sprintf(output + pos, "\\%03d", bc->data[i]);
    }
    pos += sprintf(output + pos, "\";\n");
    
    pos += sprintf(output + pos, "local __key = %d;\n", xor_key);
    
    pos += sprintf(output + pos, ""
        "local __pc = 1;\n"
        "local __stack = {};\n"
        "local __sp = 0;\n"
        "local __vars = {};\n"
        "local function __push(v) __sp = __sp + 1; __stack[__sp] = v; end\n"
        "local function __pop() local v = __stack[__sp]; __stack[__sp] = nil; __sp = __sp - 1; return v; end\n"
        "local function __read() local b = __code:byte(__pc); __pc = __pc + 1; return b; end\n"
        "local function __read_int() local i,j,k,v = __code:byte(__pc,__pc+3); __pc = __pc + 4; return v*16777216 + k*65536 + j*256 + i; end\n"
        "local function __read_double() local i,j = __read_int(),__read_int(); return j*4294967296 + i; end\n"
        "local function __read_string() local len = __read_int(); local s = __code:sub(__pc,__pc+len-1); __pc = __pc + len; return s; end\n"
        "while __pc <= #__code do\n"
        "local __op = __read();\n"
        "if __op == 1 then\n"
        "local __t = __read();\n"
        "if __t == 0 then __push(__read_double())\n"
        "elseif __t == 1 then local __s = __read_string(); local __k = __read_int(); local __r = {}; for __i = 1,#__s do __r[__i] = string.char(bit32.bxor(__s:byte(__i), __k)); end; __push(table.concat(__r));\n"
        "elseif __t == 2 then __push(__read() == 1)\n"
        "elseif __t == 3 then __push(nil)\n"
        "end\n"
        "elseif __op == 3 then local __b = __pop(); local __a = __pop(); __push(__a + __b)\n"
        "elseif __op == 4 then local __b = __pop(); local __a = __pop(); __push(__a - __b)\n"
        "elseif __op == 5 then local __b = __pop(); local __a = __pop(); __push(__a * __b)\n"
        "elseif __op == 6 then local __b = __pop(); local __a = __pop(); __push(__a / __b)\n"
        "elseif __op == 10 then local __b = __pop(); local __a = __pop(); __push(__a == __b)\n"
        "elseif __op == 11 then local __b = __pop(); local __a = __pop(); __push(__a < __b)\n"
        "elseif __op == 17 then local __n = __read_int(); local __f = __pop(); local __a = {}; for __i = __n,1,-1 do __a[__i] = __pop(); end; local __r = {__f(table.unpack(__a))}; for __i,__v in ipairs(__r) do __push(__v); end\n"
        "elseif __op == 18 then return __pop()\n"
        "elseif __op == 19 then __push(__vars[__read_string()] or _G[__read_string()])\n"
        "elseif __op == 20 then local __n = __read_string(); __vars[__n] = __pop()\n"
        "end\n"
        "end\n"
    );
    
    return output;
}

int main(int argc, char* argv[]) {
    srand(time(NULL));
    
    FILE* f = fopen("input.lua", "r");
    if (!f) return 1;
    
    fseek(f, 0, SEEK_END);
    int size = ftell(f);
    fseek(f, 0, SEEK_SET);
    
    char* code = (char*)malloc(size + 1);
    fread(code, 1, size, f);
    code[size] = '\0';
    fclose(f);
    
    Bytecode* bc = bc_create();
    int xor_key = rand() % 255 + 1;
    
    char* line = strtok(code, "\n");
    while (line) {
        compile_line(bc, line, xor_key);
        line = strtok(NULL, "\n");
    }
    
    char* output = generate_vm_lua(bc, xor_key);
    
    f = fopen("output.lua", "w");
    if (f) {
        fwrite(output, 1, strlen(output), f);
        fclose(f);
    }
    
    free(code);
    free(bc->data);
    free(bc);
    free(output);
    
    return 0;
}