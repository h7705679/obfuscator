import re
import random
import os
import string

class LuaObfuscator:
    def __init__(self):
        self.used_names = set()
        self.counter = 0
        self.keywords = {'local', 'if', 'then', 'else', 'elseif', 'end', 'for', 'while', 'do', 'repeat', 'until', 'return', 'break', 'in', 'nil', 'true', 'false', 'and', 'or', 'not', 'function'}
    
    def generate_name(self):
        letters = string.ascii_letters
        self.counter += 1
        
        if self.counter <= 52:
            name = f"{letters[self.counter - 1]}{random.randint(0, 9)}"
        elif self.counter <= 2704:
            idx = self.counter - 53
            first = idx // 52
            second = idx % 52
            name = f"{letters[first]}{letters[second]}{random.randint(0, 9)}"
        else:
            idx = self.counter - 2705
            first = idx // 2704
            rest = idx % 2704
            second = rest // 52
            third = rest % 52
            name = f"{letters[first]}{letters[second]}{letters[third]}{random.randint(0, 99)}"
        
        return name
    
    def get_unique_name(self, original):
        for _ in range(1000):
            name = self.generate_name()
            if name not in self.used_names:
                self.used_names.add(name)
                return name
        return original
    
    def process(self, code):
        var_map = {}
        func_map = {}
        
        # First pass: find all local variables AND local functions
        lines = code.split('\n')
        
        for line in lines:
            stripped = line.strip()
            
            # Skip comments
            if stripped.startswith('--'):
                continue
            
            # Match: local function func_name(...)
            func_match = re.match(r'local\s+function\s+([a-zA-Z_][a-zA-Z_0-9]*)', stripped)
            if func_match:
                func_name = func_match.group(1)
                if func_name not in func_map and func_name not in self.keywords:
                    func_map[func_name] = self.get_unique_name(func_name)
                continue
            
            # Match: local var1, var2, ... = ...
            local_match = re.match(r'local\s+(.+?)(?:\s*=|\s*$)', stripped)
            if local_match:
                vars_str = local_match.group(1)
                # Split by commas
                vars_list = [v.strip() for v in vars_str.split(',')]
                for var in vars_list:
                    # Remove any type annotations or extra stuff
                    var = var.split()[0] if var.split() else var
                    # Clean variable name
                    var_clean = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', var)
                    if var_clean:
                        var_name = var_clean.group(0)
                        if var_name != 'function' and var_name not in self.keywords:
                            if var_name not in var_map and var_name not in func_map:
                                var_map[var_name] = self.get_unique_name(var_name)
        
        # Second pass: replace all occurrences
        result = []
        i = 0
        while i < len(code):
            # Skip strings
            if code[i] in ['"', "'"]:
                quote = code[i]
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == quote:
                        j += 1
                        break
                    j += 1
                result.append(code[i:j])
                i = j
                continue
            
            # Skip comments
            if i < len(code) - 1 and code[i:i+2] == '--':
                j = code.find('\n', i)
                if j == -1:
                    j = len(code)
                result.append(code[i:j])
                i = j
                continue
            
            # Check for word
            match = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', code[i:])
            if match:
                word = match.group(0)
                # Replace function names
                if word in func_map:
                    result.append(func_map[word])
                # Replace variable names
                elif word in var_map:
                    result.append(var_map[word])
                else:
                    result.append(word)
                i += len(word)
            else:
                result.append(code[i])
                i += 1
        
        return ''.join(result)


script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    
    if code.strip():
        obf = LuaObfuscator()
        result = obf.process(code)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
        
        print(f"Done! {input_file} -> {output_file}")
        print(f"Obfuscated names: {obf.counter}")
    else:
        print("input.lua is empty")

except FileNotFoundError:
    print("input.lua not found in script directory")
except Exception as e:
    print(f"Error: {e}")