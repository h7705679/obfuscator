import os
import shutil
import subprocess
import sys

script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

def run_script(script_name):
    script_path = os.path.join(script_dir, script_name)
    print(f"\n{'='*50}")
    print(f"Running {script_name}...")
    print(f"{'='*50}")
    
    try:
        result = subprocess.run([sys.executable, script_path], 
                              cwd=script_dir,
                              capture_output=True, 
                              text=True)
        print(result.stdout)
        if result.stderr:
            print(f"Errors: {result.stderr}")
    except Exception as e:
        print(f"Failed to run {script_name}: {e}")
        sys.exit(1)

def copy_output_to_input():
    if os.path.exists(output_file):
        shutil.copy2(output_file, input_file)
        print(f"Copied {output_file} -> {input_file}")
    else:
        print(f"Warning: {output_file} not found, skipping copy")

# Main pipeline
print("Starting Lua obfuscation pipeline...")
print(f"Working directory: {script_dir}")

# Step 1: Run import re.py (obfuscate numbers + variables + one line)
run_script("import re.py")
copy_output_to_input()

# Step 2: Run Locals.py (obfuscate local variables)
run_script("Locals.py")
copy_output_to_input()

# Step 3: Run Stroke.py (compress to one line)
run_script("Stroke.py")
copy_output_to_input()

print(f"\n{'='*50}")
print("Pipeline complete!")
print(f"Final output: {output_file}")
print(f"{'='*50}")