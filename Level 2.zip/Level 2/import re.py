import re
import random
import os

class LuaNumberObfuscator:
    def __init__(self):
        self.ops = ['+', '-', '*', '/', '//', '%', '^']
    
    def obfuscate(self, num):
        is_float = '.' in str(num)
        val = float(num) if is_float else int(num)
        op = random.choice(self.ops)
        
        if op == '+':
            a = random.randint(-1000, 1000)
            b = val - a
            if is_float:
                return f"({a} + {b})"
            return f"({int(a)} + {int(b)})"
            
        elif op == '-':
            a = random.randint(-1000, 1000)
            b = a - val
            if is_float:
                return f"({a} - {b})"
            return f"({int(a)} - {int(b)})"
            
        elif op == '*':
            if val == 0:
                return f"({random.randint(1,100)} * 0)"
            av = abs(val)
            divs = []
            limit = int(av**0.5) + 1 if av == int(av) else 10
            for i in range(1, limit):
                if is_float:
                    if i != 0:
                        divs.append(i)
                else:
                    if int(av) % i == 0:
                        divs.append(i)
                        if i != int(av)//i:
                            divs.append(int(av)//i)
            if divs:
                a = random.choice(divs)
                b = val / a
                if is_float:
                    return f"({a} * {b})"
                return f"({int(a)} * {int(b)})"
            return f"({val} * 1)"
            
        elif op == '/':
            if val == 0:
                return f"(0 / {random.randint(1,100)})"
            b = random.randint(1, 100)
            a = val * b
            if is_float:
                return f"({a} / {b})"
            return f"({int(a)} / {int(b)})"
            
        elif op == '//':
            if val == 0:
                return f"(0 // {random.randint(1,100)})"
            b = random.randint(1, 20)
            a = int(val) * b + random.randint(0, b-1)
            return f"({a} // {b})"
            
        elif op == '%':
            if val == 0:
                a = random.randint(1, 100)
                return f"({a} % {a})"
            b = int(val) + random.randint(1, 50)
            a = random.randint(0, 10) * b + int(val)
            return f"({a} % {b})"
            
        elif op == '^':
            if val == 0:
                return f"(0 ^ {random.randint(1,10)})"
            if val == 1:
                return f"({random.randint(2,10)} ^ 0)"
            if val > 0 and val == int(val) and val <= 10:
                for exp in range(2, 6):
                    base = round(val ** (1/exp))
                    if base ** exp == val:
                        return f"({base} ^ {exp})"
            return f"({int(val)} ^ 1)"
    
    def process(self, code):
        def rep(m):
            n = m.group(0)
            try:
                return self.obfuscate(n)
            except:
                return n
        
        # Split code but keep strings intact
        result = []
        i = 0
        while i < len(code):
            # Check for string start
            if code[i] in ['"', "'"]:
                quote = code[i]
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == quote:
                        j += 1
                        break
                    j += 1
                result.append(code[i:j])
                i = j
                continue
            
            # Check for comment start
            if i < len(code) - 1 and code[i:i+2] == '--':
                j = code.find('\n', i)
                if j == -1:
                    j = len(code)
                result.append(code[i:j])
                i = j
                continue
            
            # Find next number position
            match = re.search(r'(?<![a-zA-Z_0-9.])-?\d+\.?\d*(?![a-zA-Z_0-9.])', code[i:])
            if match:
                start = i + match.start()
                end = i + match.end()
                # Add text before number
                result.append(code[i:start])
                # Obfuscate number
                result.append(self.obfuscate(match.group(0)))
                i = end
            else:
                result.append(code[i:])
                break
        
        return ''.join(result)


# Get script directory
script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

# Read input.lua
try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    
    if code.strip():
        obf = LuaNumberObfuscator()
        result = obf.process(code)
        
        # Write output.lua
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
        
        print(f"Done! {input_file} -> {output_file}")
    else:
        print("input.lua is empty")

except FileNotFoundError:
    print("input.lua not found in script directory")
except Exception as e:
    print(f"Error: {e}")