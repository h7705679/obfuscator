import os
import shutil
import subprocess
import sys

script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

def run_script(script_name):
    script_path = os.path.join(script_dir, script_name)
    print(f"\n{'='*50}")
    print(f"Running {script_name}...")
    print(f"{'='*50}")
    
    try:
        result = subprocess.run([sys.executable, script_path], 
                              cwd=script_dir,
                              capture_output=True, 
                              text=True)
        print(result.stdout)
        if result.stderr:
            print(f"Errors: {result.stderr}")
            return False
        return True
    except Exception as e:
        print(f"Failed to run {script_name}: {e}")
        return False

def copy_output_to_input():
    if os.path.exists(output_file):
        shutil.copy2(output_file, input_file)
        print(f"Copied {output_file} -> {input_file}")
    else:
        print(f"Warning: {output_file} not found")

# Level 1 Pipeline
print("Starting Level 1 obfuscation...")
print(f"Working directory: {script_dir}")

# Step 1: Level1.py (obfuscate numbers + variables + one line)
if run_script("Level1.py"):
    copy_output_to_input()
else:
    print("Level1.py failed!")
    sys.exit(1)

# Step 2: bit32.py (encrypt strings)
if run_script("bit32.py"):
    copy_output_to_input()
else:
    print("bit32.py failed!")
    sys.exit(1)

print(f"\n{'='*50}")
print("Level 1 complete!")
print(f"Final output: {output_file}")
print(f"{'='*50}")