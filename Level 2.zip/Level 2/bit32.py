import re
import random
import os

class StringObfuscator:
    def __init__(self):
        self.key = random.randint(1, 255)
    
    def xor_encrypt(self, text):
        """XOR encrypt string, returns array of bytes"""
        return [ord(c) ^ self.key for c in text]
    
    def obfuscate_string(self, s):
        """Obfuscate a string literal using XOR + string.char"""
        encrypted = self.xor_encrypt(s)
        chars = ','.join(str(b) for b in encrypted)
        return f'(function() local t={{{chars}}} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],{self.key})) end return table.concat(t) end)()'
    
    def process(self, code):
        result = []
        i = 0
        
        while i < len(code):
            # Handle short strings
            if code[i] == '"':
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == '"':
                        j += 1
                        break
                    j += 1
                
                str_content = code[i+1:j-1]  # String without quotes
                obfuscated = self.obfuscate_string(str_content)
                result.append(obfuscated)
                i = j
                continue
            
            # Handle single-quoted strings
            if code[i] == "'":
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == "'":
                        j += 1
                        break
                    j += 1
                
                str_content = code[i+1:j-1]  # String without quotes
                obfuscated = self.obfuscate_string(str_content)
                result.append(obfuscated)
                i = j
                continue
            
            # Handle long strings [[...]] or [=[...]=]
            if code[i] == '[':
                match = re.match(r'\[(=*)\[', code[i:])
                if match:
                    eq_len = len(match.group(1))
                    end_pattern = ']' + '=' * eq_len + ']'
                    end_idx = code.find(end_pattern, i + 2 + eq_len)
                    if end_idx != -1:
                        str_content = code[i+2+eq_len:end_idx]
                        obfuscated = self.obfuscate_string(str_content)
                        result.append(obfuscated)
                        i = end_idx + len(end_pattern)
                        continue
            
            # Skip comments
            if i < len(code) - 1 and code[i:i+2] == '--':
                if code[i:i+4] == '--[[':
                    end_idx = code.find(']]', i + 4)
                    if end_idx != -1:
                        result.append(code[i:end_idx+2])
                        i = end_idx + 2
                        continue
                else:
                    j = code.find('\n', i)
                    if j == -1:
                        j = len(code)
                    result.append(code[i:j])
                    i = j
                    continue
            
            result.append(code[i])
            i += 1
        
        return ''.join(result)


script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    
    if code.strip():
        obf = StringObfuscator()
        result = obf.process(code)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
        
        print(f"Done! {input_file} -> {output_file}")
        print(f"XOR key: {obf.key}")
    else:
        print("input.lua is empty")

except FileNotFoundError:
    print("input.lua not found in script directory")
except Exception as e:
    print(f"Error: {e}")