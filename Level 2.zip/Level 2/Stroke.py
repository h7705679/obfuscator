import re
import os

class LuaStroke:
    def process(self, code):
        result = []
        i = 0
        
        while i < len(code):
            # Keep strings intact
            if code[i] in ['"', "'"]:
                quote = code[i]
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == quote:
                        j += 1
                        break
                    j += 1
                result.append(code[i:j])
                i = j
                continue
            
            # Keep comments but remove newline after them
            if i < len(code) - 1 and code[i:i+2] == '--':
                j = code.find('\n', i)
                if j == -1:
                    j = len(code)
                comment = code[i:j]
                # Check if it's a multiline comment --[[]]
                if comment.startswith('--[['):
                    end_idx = code.find(']]', i)
                    if end_idx != -1:
                        j = end_idx + 2
                        result.append(code[i:j])
                        i = j
                        continue
                result.append(comment + ' ')
                i = j
                continue
            
            # Replace whitespace with single space
            if code[i] in ' \t\r\n':
                # Check if previous char needs space
                if result and not result[-1].endswith(' '):
                    result.append(' ')
                i += 1
                continue
            
            result.append(code[i])
            i += 1
        
        # Clean up multiple spaces
        output = ''.join(result)
        output = re.sub(r' {2,}', ' ', output)
        output = output.strip()
        
        return output


script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    
    if code.strip():
        obf = LuaStroke()
        result = obf.process(code)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
        
        print(f"Done! {input_file} -> {output_file}")
        print(f"Original lines: {len(code.splitlines())}")
        print(f"Result: 1 line, {len(result)} chars")
    else:
        print("input.lua is empty")

except FileNotFoundError:
    print("input.lua not found in script directory")
except Exception as e:
    print(f"Error: {e}")