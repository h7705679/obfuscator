import re
import random
import os
import string

class LuaObfuscator:
    def __init__(self):
        self.used_names = set()
        self.counter = 0
        self.keywords = {'local', 'if', 'then', 'else', 'elseif', 'end', 'for', 'while', 'do', 'repeat', 'until', 'return', 'break', 'in', 'nil', 'true', 'false', 'and', 'or', 'not', 'function'}
        self.builtins = {'game', 'Game', 'workspace', 'Workspace', 'script', 'Script', 'require', 'print', 'warn', 'error', 'assert', 'type', 'tonumber', 'tostring', 'pairs', 'ipairs', 'next', 'select', 'unpack', 'table', 'string', 'math', 'os', 'io', 'debug', 'coroutine', 'bit32', 'rawget', 'rawset', 'rawequal', 'rawlen', 'setmetatable', 'getmetatable', 'pcall', 'xpcall', 'loadstring', 'load', 'dofile', 'loadfile', 'Vector3', 'Vector2', 'CFrame', 'Color3', 'BrickColor', 'TweenInfo', 'UDim2', 'UDim', 'Rect', 'Ray', 'Region3', 'Enum', 'Instance', 'Player', 'Players', 'Character', 'Humanoid', 'Torso', 'Head', 'LocalPlayer', 'Mouse', 'RenderStepped', 'Heartbeat', 'Stepped', 'CanCollide', 'Size', 'Transparency', 'Position', 'Color', 'Anchored', 'Name', 'Parent', 'Value', 'Text', 'Visible', 'Locked', 'Orientation', 'Rotation', 'Velocity', 'Mass', 'GetService', 'GetPlayers', 'FindFirstChild', 'IsA', 'Connect', 'new'}
    
    def generate_name(self):
        letters = string.ascii_letters
        self.counter += 1
        if self.counter <= 52:
            name = f"{letters[self.counter - 1]}{random.randint(0, 9)}"
        elif self.counter <= 2704:
            idx = self.counter - 53
            first = idx // 52
            second = idx % 52
            name = f"{letters[first]}{letters[second]}{random.randint(0, 9)}"
        else:
            idx = self.counter - 2705
            first = idx // 2704
            rest = idx % 2704
            second = rest // 52
            third = rest % 52
            name = f"{letters[first]}{letters[second]}{letters[third]}{random.randint(0, 99)}"
        return name
    
    def get_unique_name(self):
        for _ in range(1000):
            name = self.generate_name()
            if name not in self.used_names and name not in self.keywords and name not in self.builtins:
                self.used_names.add(name)
                return name
        return f"var{self.counter}"
    
    def is_used_as_object(self, code, var_name):
        pattern1 = re.escape(var_name) + r'\s*\.'
        pattern2 = re.escape(var_name) + r'\s*:'
        if re.search(pattern1, code) or re.search(pattern2, code):
            return True
        return False
    
    def is_local_declaration(self, code, var_name):
        lines = code.split('\n')
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('--'):
                continue
            
            local_match = re.match(r'local\s+(.+?)(?:\s*=|\s*$)', stripped)
            if local_match:
                vars_str = local_match.group(1)
                vars_list = [v.strip().split()[0] for v in vars_str.split(',')]
                if var_name in vars_list:
                    return True
            
            func_match = re.match(r'local\s+function\s+([a-zA-Z_][a-zA-Z_0-9]*)', stripped)
            if func_match and func_match.group(1) == var_name:
                return True
            
            for_match = re.match(r'for\s+([a-zA-Z_][a-zA-Z_0-9]*)\s*,\s*([a-zA-Z_][a-zA-Z_0-9]*)\s+in', stripped)
            if for_match:
                if for_match.group(1) == var_name or for_match.group(2) == var_name:
                    return True
            
            for_match2 = re.match(r'for\s+([a-zA-Z_][a-zA-Z_0-9]*)\s*=', stripped)
            if for_match2 and for_match2.group(1) == var_name:
                return True
            
            func_params = re.match(r'(?:local\s+)?function\s+[a-zA-Z_][a-zA-Z_0-9]*\s*\(([^)]*)\)', stripped)
            if func_params:
                params = [p.strip() for p in func_params.group(1).split(',')]
                if var_name in params:
                    return True
        
        return False
    
    def collect_variables(self, code):
        var_map = {}
        
        i = 0
        while i < len(code):
            if code[i] in ['"', "'"]:
                quote = code[i]
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == quote:
                        j += 1
                        break
                    j += 1
                i = j
                continue
            
            if i < len(code) - 1 and code[i:i+2] == '--':
                j = code.find('\n', i)
                if j == -1:
                    j = len(code)
                i = j
                continue
            
            if code[i] == '[':
                match = re.match(r'\[(=*)\[', code[i:])
                if match:
                    eq_len = len(match.group(1))
                    end_pattern = ']' + '=' * eq_len + ']'
                    end_idx = code.find(end_pattern, i + 2 + eq_len)
                    if end_idx != -1:
                        i = end_idx + len(end_pattern)
                        continue
            
            match = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', code[i:])
            if match:
                word = match.group(0)
                next_char = code[i + len(word)] if i + len(word) < len(code) else ''
                prev_char = code[i - 1] if i > 0 else ''
                
                if prev_char != '.' and prev_char != ':' and next_char != '.' and next_char != ':':
                    if word not in self.keywords and word not in self.builtins and word != '_':
                        if word not in var_map and self.is_local_declaration(code, word):
                            if not self.is_used_as_object(code, word):
                                var_map[word] = self.get_unique_name()
                i += len(word)
            else:
                i += 1
        
        return var_map
    
    def replace_variables(self, code, var_map):
        result = []
        i = 0
        
        while i < len(code):
            if code[i] in ['"', "'"]:
                quote = code[i]
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == quote:
                        j += 1
                        break
                    j += 1
                result.append(code[i:j])
                i = j
                continue
            
            if i < len(code) - 1 and code[i:i+2] == '--':
                j = code.find('\n', i)
                if j == -1:
                    j = len(code)
                result.append(code[i:j])
                i = j
                continue
            
            if code[i] == '[':
                match = re.match(r'\[(=*)\[', code[i:])
                if match:
                    eq_len = len(match.group(1))
                    end_pattern = ']' + '=' * eq_len + ']'
                    end_idx = code.find(end_pattern, i + 2 + eq_len)
                    if end_idx != -1:
                        result.append(code[i:end_idx+len(end_pattern)])
                        i = end_idx + len(end_pattern)
                        continue
            
            match = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', code[i:])
            if match:
                word = match.group(0)
                next_char = code[i + len(word)] if i + len(word) < len(code) else ''
                prev_char = code[i - 1] if i > 0 else ''
                
                if prev_char == '.' or prev_char == ':' or next_char == '.' or next_char == ':':
                    result.append(word)
                elif word in var_map:
                    result.append(var_map[word])
                else:
                    result.append(word)
                i += len(word)
            else:
                result.append(code[i])
                i += 1
        
        return ''.join(result)
    
    def process(self, code):
        var_map = self.collect_variables(code)
        return self.replace_variables(code, var_map)


script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    if code.strip():
        obf = LuaObfuscator()
        result = obf.process(code)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
except:
    pass