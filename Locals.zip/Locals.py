import re
import random
import os
import string

class LuaObfuscator:
    def __init__(self):
        self.used_names = set()
        self.counter = 0
        self.keywords = {'local', 'if', 'then', 'else', 'elseif', 'end', 'for', 'while', 'do', 'repeat', 'until', 'return', 'break', 'in', 'nil', 'true', 'false', 'and', 'or', 'not', 'function'}
        self.builtins = {'game', 'Game', 'workspace', 'Workspace', 'script', 'Script', 'require', 'print', 'warn', 'error', 'assert', 'type', 'tonumber', 'tostring', 'pairs', 'ipairs', 'next', 'select', 'unpack', 'table', 'string', 'math', 'os', 'io', 'debug', 'coroutine', 'bit32', 'rawget', 'rawset', 'rawequal', 'rawlen', 'setmetatable', 'getmetatable', 'pcall', 'xpcall', 'loadstring', 'load', 'dofile', 'loadfile', 'require', 'Vector3', 'Vector2', 'CFrame', 'Color3', 'BrickColor', 'TweenInfo', 'UDim2', 'UDim', 'Rect', 'Ray', 'Region3', 'Enum', 'Instance', 'player', 'Player', 'Players', 'Character', 'Humanoid', 'Torso', 'Head', 'LocalPlayer', 'Mouse', 'KeyDown', 'KeyUp', 'Button1Down', 'Button1Up'}
    
    def generate_name(self):
        letters = string.ascii_letters
        self.counter += 1
        if self.counter <= 52:
            name = f"{letters[self.counter - 1]}{random.randint(0, 9)}"
        elif self.counter <= 2704:
            idx = self.counter - 53
            first = idx // 52
            second = idx % 52
            name = f"{letters[first]}{letters[second]}{random.randint(0, 9)}"
        else:
            idx = self.counter - 2705
            first = idx // 2704
            rest = idx % 2704
            second = rest // 52
            third = rest % 52
            name = f"{letters[first]}{letters[second]}{letters[third]}{random.randint(0, 99)}"
        return name
    
    def get_unique_name(self, original):
        for _ in range(1000):
            name = self.generate_name()
            if name not in self.used_names and name not in self.keywords and name not in self.builtins:
                self.used_names.add(name)
                return name
        return original
    
    def is_protected_name(self, name):
        return name in self.keywords or name in self.builtins or name == 'function'
    
    def process(self, code):
        var_map = {}
        func_map = {}
        lines = code.split('\n')
        
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('--'):
                continue
            
            func_match = re.match(r'local\s+function\s+([a-zA-Z_][a-zA-Z_0-9]*)', stripped)
            if func_match:
                func_name = func_match.group(1)
                if not self.is_protected_name(func_name) and func_name not in func_map:
                    func_map[func_name] = self.get_unique_name(func_name)
                continue
            
            local_match = re.match(r'local\s+(.+?)(?:\s*=|\s*$)', stripped)
            if local_match:
                vars_str = local_match.group(1)
                vars_list = [v.strip() for v in vars_str.split(',')]
                for var in vars_list:
                    var = var.split()[0] if var.split() else var
                    var_clean = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', var)
                    if var_clean:
                        var_name = var_clean.group(0)
                        if not self.is_protected_name(var_name) and var_name not in var_map and var_name not in func_map:
                            var_map[var_name] = self.get_unique_name(var_name)
        
        result = []
        i = 0
        while i < len(code):
            if code[i] in ['"', "'"]:
                quote = code[i]
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == quote:
                        j += 1
                        break
                    j += 1
                result.append(code[i:j])
                i = j
                continue
            
            if i < len(code) - 1 and code[i:i+2] == '--':
                j = code.find('\n', i)
                if j == -1:
                    j = len(code)
                result.append(code[i:j])
                i = j
                continue
            
            if i > 0 and code[i-1] == '.':
                match = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', code[i:])
                if match:
                    result.append(match.group(0))
                    i += len(match.group(0))
                    continue
            
            if i > 0 and code[i-1] == ':':
                match = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', code[i:])
                if match:
                    result.append(match.group(0))
                    i += len(match.group(0))
                    continue
            
            match = re.match(r'[a-zA-Z_][a-zA-Z_0-9]*', code[i:])
            if match:
                word = match.group(0)
                if i + len(word) < len(code) and code[i + len(word)] == '.':
                    result.append(word)
                elif i + len(word) < len(code) and code[i + len(word)] == ':':
                    result.append(word)
                elif word in func_map:
                    result.append(func_map[word])
                elif word in var_map:
                    result.append(var_map[word])
                else:
                    result.append(word)
                i += len(word)
            else:
                result.append(code[i])
                i += 1
        
        return ''.join(result)


script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    if code.strip():
        obf = LuaObfuscator()
        result = obf.process(code)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
except:
    pass