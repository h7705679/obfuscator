local function d(t)
print(t)
end