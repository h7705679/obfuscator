local L_10_ = game:GetService((function() local t={200,244,249,225,253,234,235} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],152)) end return table.concat(t) end)()).LocalPlayer
local x = (1 * 20)
local y = Vector3.new(x, x, x)
local z = (3 // 4)

game:GetService((function() local t={202,237,246,203,253,234,238,241,251,253} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],152)) end return table.concat(t) end)()).RenderStepped:Connect(function()
    for _, L_17_ in ipairs(game:GetService((function() local t={200,244,249,225,253,234,235} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],152)) end return table.concat(t) end)()):GetPlayers()) do
        if L_17_ ~= L_10_ and L_17_.Character then
            local L_20_ = L_17_.Character:FindFirstChild((function() local t={208,237,245,249,246,247,241,252,202,247,247,236,200,249,234,236} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],152)) end return table.concat(t) end)())
            if L_20_ and L_20_:IsA((function() local t={218,249,235,253,200,249,234,236} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],152)) end return table.concat(t) end)()) then
                L_20_.CanCollide = false
                L_20_.Size = y
                L_20_.Transparency = z
            end
        end
    end
end)