import re
import random
import os
import string

class StringObfuscator:
    def __init__(self):
        self.key = random.randint(1, 255)
        self.search_methods = {'FindFirstChild', 'WaitForChild', 'FindFirstChildOfClass', 'FindFirstChildWhichIsA', 'FindFirstAncestor', 'FindFirstAncestorOfClass', 'FindFirstAncestorWhichIsA', 'GetService', 'GetChildren', 'GetDescendants', 'GetAttribute', 'SetAttribute', 'FireServer', 'FireClient', 'FireAllClients', 'InvokeServer', 'InvokeClient', 'IsA', 'Clone', 'Destroy', 'Remove', 'LoadAsset', 'GetFullName', 'Connect', 'Disconnect', 'Play', 'Stop', 'Pause', 'Resume', 'Load', 'Save', 'Kick', 'Ban', 'Teleport', 'GetPropertyChangedSignal', 'Changed', 'ChildAdded', 'ChildRemoved', 'DescendantAdded', 'DescendantRemoving', 'TweenPosition', 'TweenSize', 'TweenSizeAndPosition', 'new', 'Create', 'SetPrimaryPartCFrame', 'BreakJoints', 'MakeJoints', 'Require'}
        self.rbx_classes = {'Instance', 'Part', 'Model', 'Script', 'LocalScript', 'ModuleScript', 'Folder', 'StringValue', 'IntValue', 'BoolValue', 'NumberValue', 'ObjectValue', 'Vector3Value', 'CFrameValue', 'Color3Value', 'BrickColorValue', 'RemoteEvent', 'RemoteFunction', 'BindableEvent', 'BindableFunction', 'Player', 'Players', 'Workspace', 'Game', 'ReplicatedStorage', 'ServerStorage', 'ServerScriptService', 'StarterGui', 'StarterPack', 'StarterPlayer', 'SoundService', 'RunService', 'UserInputService', 'ContextActionService', 'HttpService', 'TeleportService', 'MarketplaceService', 'DataStoreService', 'BadgeService', 'GroupService', 'Chat', 'Lighting', 'Debris', 'TweenService', 'CollectionService', 'PathfindingService', 'ProximityPromptService', 'VRService', 'TextService', 'LocalizationService', 'SocialService', 'Teams', 'InsertService', 'MeshContentProvider', 'SolidModelContentProvider', 'TestService', 'UGCValidationService'}
    
    def xor_encrypt(self, text):
        return [ord(c) ^ self.key for c in text]
    
    def obfuscate_string(self, s):
        encrypted = self.xor_encrypt(s)
        chars = ','.join(str(b) for b in encrypted)
        return f'(function() local t={{{chars}}} for i=1,#t do t[i]=string.char(bit32.bxor(t[i],{self.key})) end return table.concat(t) end)()'
    
    def is_protected_method(self, code, pos):
        if pos > 0 and code[pos-1] == ':':
            return True
        
        if pos > 0 and code[pos-1] == '.':
            j = pos - 2
            while j >= 0 and code[j] in string.ascii_letters + '_':
                j -= 1
            method_name = code[j+1:pos-1]
            
            if method_name in self.search_methods:
                return True
            
            k = j
            while k >= 0 and code[k] in ' \t\n':
                k -= 1
            if k >= 0 and code[k] == ':':
                return True
        
        return False
    
    def is_service_path(self, code, pos):
        j = pos - 1
        while j >= 0 and code[j] in ' \t\n':
            j -= 1
        
        if j >= 0 and code[j] in '."\'':
            k = j - 1
            while k >= 0 and code[k] in string.ascii_letters + '_':
                k -= 1
            word = code[k+1:j]
            if word in self.rbx_classes:
                return True
        
        return False
    
    def process(self, code):
        result = []
        i = 0
        
        while i < len(code):
            if code[i] == '"':
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == '"':
                        j += 1
                        break
                    j += 1
                if self.is_protected_method(code, i) or self.is_service_path(code, i):
                    result.append(code[i:j])
                else:
                    str_content = code[i+1:j-1]
                    result.append(self.obfuscate_string(str_content))
                i = j
                continue
            
            if code[i] == "'":
                j = i + 1
                while j < len(code):
                    if code[j] == '\\':
                        j += 2
                        continue
                    if code[j] == "'":
                        j += 1
                        break
                    j += 1
                if self.is_protected_method(code, i) or self.is_service_path(code, i):
                    result.append(code[i:j])
                else:
                    str_content = code[i+1:j-1]
                    result.append(self.obfuscate_string(str_content))
                i = j
                continue
            
            if code[i] == '[':
                match = re.match(r'\[(=*)\[', code[i:])
                if match:
                    eq_len = len(match.group(1))
                    end_pattern = ']' + '=' * eq_len + ']'
                    end_idx = code.find(end_pattern, i + 2 + eq_len)
                    if end_idx != -1:
                        if self.is_protected_method(code, i) or self.is_service_path(code, i):
                            result.append(code[i:end_idx+len(end_pattern)])
                        else:
                            str_content = code[i+2+eq_len:end_idx]
                            result.append(self.obfuscate_string(str_content))
                        i = end_idx + len(end_pattern)
                        continue
            
            if i < len(code) - 1 and code[i:i+2] == '--':
                if code[i:i+4] == '--[[':
                    end_idx = code.find(']]', i + 4)
                    if end_idx != -1:
                        result.append(code[i:end_idx+2])
                        i = end_idx + 2
                        continue
                else:
                    j = code.find('\n', i)
                    if j == -1:
                        j = len(code)
                    result.append(code[i:j])
                    i = j
                    continue
            
            result.append(code[i])
            i += 1
        
        return ''.join(result)


script_dir = os.path.dirname(os.path.abspath(__file__))
input_file = os.path.join(script_dir, "input.lua")
output_file = os.path.join(script_dir, "output.lua")

try:
    with open(input_file, 'r', encoding='utf-8') as f:
        code = f.read()
    if code.strip():
        obf = StringObfuscator()
        result = obf.process(code)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result)
except:
    pass